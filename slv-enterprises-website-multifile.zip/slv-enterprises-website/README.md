# SLV Enterprises Website

## Files
- `index.html` — main webpage
- `style.css` — all website styling
- `script.js` — product data and interactive functionality
- `assets/` — images, logos and other static assets

## Local preview
Open `index.html` in a browser.

## GitHub Pages / hosting
Upload the complete folder contents, keeping the same structure. Set the site root to the folder containing `index.html`.

## Important
The RFQ form currently performs client-side validation and shows a success state. It does not send form submissions to a server by itself; connect it to a form/email/API backend before production use.
