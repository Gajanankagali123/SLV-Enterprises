/* ===================== CONFIG ===================== */
const CALL_NUMBER = "+919844169916";
const WHATSAPP_NUMBER = "917829772767";

/* ===================== DATA: TOP CATEGORIES ===================== */
const topCategories = [
  {name:"Fasteners", desc:"Bolts, screws, nuts, washers and other fastening hardware.", icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14.7 6.3a4 4 0 015.7 5.6l-6.5 6.5a4 4 0 01-5.6-5.7z"/><path d="M9.2 8.2l1.6 1.6M12.3 5.1l1.6 1.6"/></svg>`},
  {name:"Industrial Hardware", desc:"Springs, castor wheels, hinges, handles, brackets, clamps and rings.", icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/></svg>`},
  {name:"Tools", desc:"Hand tools, power tools, cutting tools and measuring instruments.", icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14.7 6.3a4 4 0 015.7 5.6l-6.5 6.5a4 4 0 01-5.6-5.7l6.4-6.4z"/></svg>`},
  {name:"Industrial Equipment", desc:"Workshop, material handling, safety, CNC, robotics, automation and conveyor systems.", icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="4" y="4" width="16" height="16" rx="1"/><path d="M9 4v16M4 9h16"/></svg>`},
  {name:"Industrial Consumables", desc:"Abrasives, cutting and welding consumables, packaging and maintenance consumables.", icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7M12 11v10"/></svg>`},
  {name:"Electrical Accessories", desc:"Panel boards, switches, contactors, relays, sensors and automation components.", icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M13 2L4 14h6l-1 8 9-12h-6z"/></svg>`},
];

/* ===================== DATA: PRODUCTS ===================== */
const products = [
  // FASTENERS — BOLTS
  {name:"Hex Bolt",cat:"Fasteners",sub:"Bolts",desc:"Standard hex head bolt for general structural and mechanical fastening.",app:"Construction, machinery and general assembly."},
  {name:"Flange Bolt",cat:"Fasteners",sub:"Bolts",desc:"Bolt with an integrated flange to spread clamping load.",app:"Automotive and machinery assembly."},
  {name:"Carriage Bolt",cat:"Fasteners",sub:"Bolts",desc:"Round-head, square-neck bolt that resists turning once seated.",app:"Timber and structural fastening."},
  {name:"Socket Head Bolt",cat:"Fasteners",sub:"Bolts",desc:"High-strength bolt with a hexagonal socket drive.",app:"Precision machinery and equipment assembly."},
  {name:"Special Bolts",cat:"Fasteners",sub:"Bolts",desc:"Non-standard bolts sourced to a supplied drawing or sample.",app:"Contact SLV Enterprises with your specification."},
  // FASTENERS — SCREWS
  {name:"Allen Screw",cat:"Fasteners",sub:"Screws",desc:"Socket-head screw driven with a hex key.",app:"Precision assembly where a low profile head is needed."},
  {name:"CSK Screw",cat:"Fasteners",sub:"Screws",desc:"Countersunk screw for a flush finish.",app:"Panel and flush-surface fixing."},
  {name:"Machine Screw",cat:"Fasteners",sub:"Screws",desc:"Uniform-thread screw for machined tapped holes.",app:"Equipment and enclosure assembly."},
  {name:"Self-Tapping Screw",cat:"Fasteners",sub:"Screws",desc:"Screw that cuts its own thread into the material.",app:"Sheet metal and plastic fixing."},
  {name:"D-Ring Screw",cat:"Fasteners",sub:"Screws",desc:"Screw fitted with a D-shaped ring for tie-down applications.",app:"Load securing and tie-down fixtures."},
  {name:"Thumb Screw",cat:"Fasteners",sub:"Screws",desc:"Hand-tightened screw for tool-free adjustment.",app:"Panels and fixtures needing frequent access."},
  {name:"Flanged Screw",cat:"Fasteners",sub:"Screws",desc:"Screw with an integrated flange bearing surface.",app:"Applications avoiding a separate washer."},
  {name:"Special Screws",cat:"Fasteners",sub:"Screws",desc:"Non-standard screws sourced to a supplied drawing or sample.",app:"Contact SLV Enterprises with your specification."},
  // FASTENERS — NUTS
  {name:"Hex Nut",cat:"Fasteners",sub:"Nuts",desc:"Standard hex nut for general fastening.",app:"General industrial applications."},
  {name:"Lock Nut",cat:"Fasteners",sub:"Nuts",desc:"Nut designed to resist loosening under vibration.",app:"Machinery and automotive assemblies."},
  {name:"Clinch Nut",cat:"Fasteners",sub:"Nuts",desc:"Nut pressed permanently into sheet metal.",app:"Electronics enclosures and sheet metal assembly."},
  {name:"Flange Nut",cat:"Fasteners",sub:"Nuts",desc:"Nut with an integrated flange to spread clamping load.",app:"Applications needing a wider bearing surface."},
  {name:"Special Nuts",cat:"Fasteners",sub:"Nuts",desc:"Non-standard nuts sourced to a supplied drawing or sample.",app:"Contact SLV Enterprises with your specification."},
  // FASTENERS — WASHERS
  {name:"Flat Washer",cat:"Fasteners",sub:"Washers",desc:"Standard flat washer for load distribution.",app:"General purpose fastening."},
  {name:"Spring Washer",cat:"Fasteners",sub:"Washers",desc:"Split spring washer that resists loosening.",app:"Joints subject to vibration."},
  {name:"Metal Washer",cat:"Fasteners",sub:"Washers",desc:"Machined metal washer for bearing surface protection.",app:"General assembly."},
  {name:"Special Washers",cat:"Fasteners",sub:"Washers",desc:"Non-standard washers sourced to a supplied drawing or sample.",app:"Contact SLV Enterprises with your specification."},
  // FASTENERS — OTHER
  {name:"Circlips",cat:"Fasteners",sub:"Other Fasteners",desc:"Internal and external retaining rings for shaft and bore retention.",app:"Rotating shaft assemblies."},
  {name:"Rivets",cat:"Fasteners",sub:"Other Fasteners",desc:"Rivet range for permanent single or double-sided joining.",app:"Sheet metal and panel joining."},
  {name:"Threaded Rods",cat:"Fasteners",sub:"Other Fasteners",desc:"Fully threaded rod for double-ended fastening.",app:"Flange, suspension and equipment mounting."},
  {name:"Pins",cat:"Fasteners",sub:"Other Fasteners",desc:"Dowel, spring and split pin range for locating and securing.",app:"Precision alignment and mechanical linkages."},
  {name:"Clips",cat:"Fasteners",sub:"Other Fasteners",desc:"Retaining and fixing clip range.",app:"Panel and cable fixing."},
  {name:"Special Fasteners",cat:"Fasteners",sub:"Other Fasteners",desc:"Non-standard fastening components sourced to specification.",app:"Contact SLV Enterprises with your requirement."},
  // INDUSTRIAL HARDWARE
  {name:"Springs",cat:"Industrial Hardware",sub:"General Hardware",desc:"Compression, extension and mechanical spring range.",app:"Machinery and equipment assembly."},
  {name:"Castor Wheels",cat:"Industrial Hardware",sub:"General Hardware",desc:"Fixed and swivel castor wheels for mobile equipment.",app:"Trolleys, workstations and mobile fixtures."},
  {name:"Hinges",cat:"Industrial Hardware",sub:"General Hardware",desc:"Industrial hinge range for panels, doors and enclosures.",app:"Cabinet, panel and door assembly."},
  {name:"Handles",cat:"Industrial Hardware",sub:"General Hardware",desc:"Handle range for panels, doors and equipment.",app:"Enclosure and equipment access points."},
  {name:"Brackets",cat:"Industrial Hardware",sub:"General Hardware",desc:"Mounting bracket range for structural and equipment fixing.",app:"Support and mounting applications."},
  {name:"Clamps",cat:"Industrial Hardware",sub:"General Hardware",desc:"Clamp range for securing components and workpieces.",app:"Assembly, fabrication and jig work."},
  {name:"D-Rings",cat:"Industrial Hardware",sub:"General Hardware",desc:"D-ring hardware for tie-down and load securing.",app:"Load securing applications."},
  {name:"Rings",cat:"Industrial Hardware",sub:"General Hardware",desc:"Retaining and mounting ring range for general hardware use.",app:"General assembly and mounting."},
  {name:"Mounting Hardware",cat:"Industrial Hardware",sub:"General Hardware",desc:"General mounting hardware for equipment installation.",app:"Equipment and panel mounting."},
  {name:"General Industrial Hardware",cat:"Industrial Hardware",sub:"General Hardware",desc:"General-purpose hardware components for everyday industrial assembly needs.",app:"Contact SLV Enterprises with your requirement."},
  // TOOLS
  {name:"Hand Tools",cat:"Tools",sub:"Hand Tools",desc:"General hand tool range for maintenance and assembly.",app:"Workshops, maintenance and site work."},
  {name:"Power Tools",cat:"Tools",sub:"Power Tools",desc:"Power tool range for drilling, fastening and finishing.",app:"Production and site installation work."},
  {name:"Cutting Tools",cat:"Tools",sub:"Cutting Tools",desc:"Cutting tool range for machining operations.",app:"Manufacturing and metalworking."},
  {name:"Measuring Tools",cat:"Tools",sub:"Measuring Tools",desc:"Measuring and inspection instrument range.",app:"Quality control and dimensional checking."},
  {name:"Workshop Tools",cat:"Tools",sub:"Workshop Tools",desc:"General workshop tooling for daily operations.",app:"Workshop and maintenance activity."},
  {name:"Assembly Tools",cat:"Tools",sub:"Assembly Tools",desc:"Tools used in product and equipment assembly.",app:"Production line assembly."},
  {name:"Maintenance Tools",cat:"Tools",sub:"Maintenance Tools",desc:"Tools supporting equipment upkeep and repair.",app:"Preventive and corrective maintenance."},
  // INDUSTRIAL EQUIPMENT
  {name:"Workshop Equipment",cat:"Industrial Equipment",sub:"Workshop",desc:"Equipment supporting general workshop operations.",app:"Workshop and fabrication activity."},
  {name:"Material Handling Equipment",cat:"Industrial Equipment",sub:"Material Handling",desc:"Equipment for moving and positioning materials.",app:"Warehousing and production floor logistics."},
  {name:"Maintenance Equipment",cat:"Industrial Equipment",sub:"Maintenance",desc:"Equipment used for plant and machinery maintenance.",app:"Preventive and corrective maintenance."},
  {name:"Engineering Equipment",cat:"Industrial Equipment",sub:"Engineering",desc:"Equipment supporting general engineering operations.",app:"Engineering and technical work."},
  {name:"Safety Equipment",cat:"Industrial Equipment",sub:"Safety",desc:"Personal protective and workplace safety equipment for industrial environments.",app:"Workshop, site and dispatch-floor safety compliance."},
  {name:"CNC Machines",cat:"Industrial Equipment",sub:"CNC & Automation",desc:"Precision components and industrial supplies supporting CNC machining and engineering requirements.",app:"Precision machining and component manufacturing."},
  {name:"Robotics",cat:"Industrial Equipment",sub:"CNC & Automation",desc:"Components and supplies supporting robotic and automated systems.",app:"Automated production and assembly lines."},
  {name:"Industrial Automation",cat:"Industrial Equipment",sub:"CNC & Automation",desc:"Components supporting automation and control systems.",app:"Automated manufacturing processes."},
  {name:"Conveyor Systems",cat:"Industrial Equipment",sub:"Conveyors",desc:"Conveyor components including rollers, fasteners and safety elements for material handling systems.",app:"Production line and material handling systems."},
  // INDUSTRIAL CONSUMABLES
  {name:"Abrasives",cat:"Industrial Consumables",sub:"Consumables",desc:"Grinding, cutting and finishing abrasive range.",app:"Fabrication and surface finishing."},
  {name:"Cutting Consumables",cat:"Industrial Consumables",sub:"Consumables",desc:"Consumables supporting cutting and machining operations, including blades and discs.",app:"Metal cutting, fabrication and machining work."},
  {name:"Welding Consumables",cat:"Industrial Consumables",sub:"Consumables",desc:"Consumables supporting welding operations.",app:"Fabrication and construction work."},
  {name:"Packaging Materials",cat:"Industrial Consumables",sub:"Consumables",desc:"Packaging materials for dispatch and storage.",app:"Industrial packing and logistics."},
  {name:"Maintenance Consumables",cat:"Industrial Consumables",sub:"Consumables",desc:"Consumables supporting routine plant maintenance.",app:"Preventive maintenance activity."},
  // ELECTRICAL ACCESSORIES
  {name:"Control Panels",cat:"Electrical Accessories",sub:"Panels & Boards",desc:"Control cabinet and panel components for electrical installations.",app:"Industrial panel board assembly."},
  {name:"Panel Boards",cat:"Electrical Accessories",sub:"Panels & Boards",desc:"Industrial panel board components including DIN rail hardware.",app:"Electrical distribution and control panels."},
  {name:"Industrial Switches",cat:"Electrical Accessories",sub:"Switching & Control",desc:"Switch range for industrial electrical installations.",app:"Machine and panel control circuits."},
  {name:"Push Buttons",cat:"Electrical Accessories",sub:"Switching & Control",desc:"Push button components for control panels.",app:"Machine start/stop and control functions."},
  {name:"Indicators",cat:"Electrical Accessories",sub:"Switching & Control",desc:"Indicator lamps and signal components for panels.",app:"Status indication on control panels."},
  {name:"Contactors",cat:"Electrical Accessories",sub:"Switching & Control",desc:"Contactor components for motor and load switching.",app:"Motor control circuits."},
  {name:"Relays",cat:"Electrical Accessories",sub:"Switching & Control",desc:"Relay components for control and switching circuits.",app:"Control panel and automation circuits."},
  {name:"Circuit Protection Components",cat:"Electrical Accessories",sub:"Protection",desc:"Components for circuit protection in electrical installations.",app:"Electrical panel protection."},
  {name:"Terminal Blocks",cat:"Electrical Accessories",sub:"Wiring Accessories",desc:"Terminal block components for wiring connections.",app:"Panel wiring and cable termination."},
  {name:"Cable Glands",cat:"Electrical Accessories",sub:"Wiring Accessories",desc:"Cable gland components for cable entry sealing.",app:"Enclosure and panel cable entries."},
  {name:"Connectors",cat:"Electrical Accessories",sub:"Wiring Accessories",desc:"Electrical connector range for industrial wiring.",app:"Cable and equipment connections."},
  {name:"Industrial Cables",cat:"Electrical Accessories",sub:"Wiring Accessories",desc:"Cable range for industrial electrical installations.",app:"Power and control wiring."},
  {name:"Sensors",cat:"Electrical Accessories",sub:"Automation Components",desc:"Sensor components supporting automation and control systems.",app:"Automated process monitoring."},
  {name:"Automation Components",cat:"Electrical Accessories",sub:"Automation Components",desc:"General components supporting automation systems.",app:"Automated manufacturing systems."},
  {name:"VFD / Drive-Related Equipment",cat:"Electrical Accessories",sub:"Automation Components",desc:"Components related to variable frequency drives and motor control.",app:"Motor speed control applications."},
  {name:"Control Components",cat:"Electrical Accessories",sub:"Automation Components",desc:"General control components for panels and systems.",app:"Industrial control systems."},
];

const categories = ["All","Fasteners","Industrial Hardware","Tools","Industrial Equipment","Industrial Consumables","Electrical Accessories"];

const industries = [
  {name:"Automotive", d:"Fasteners, hardware and industrial components used in automotive manufacturing and assembly."},
  {name:"Engineering & Manufacturing", d:"Industrial fasteners, tools and consumables for machinery and manufacturing operations."},
  {name:"Fabrication", d:"Fasteners, hardware and consumables for fabrication workshops and engineering projects."},
  {name:"Furniture", d:"Screws, fasteners, brackets, hinges, castors and other furniture hardware."},
  {name:"Construction", d:"Industrial hardware, fasteners and accessories for construction applications."},
  {name:"Electrical", d:"Fasteners, hardware and accessories required for electrical equipment and installations."},
  {name:"Solar", d:"Industrial fasteners, hardware and accessories for solar-related applications."},
  {name:"Machinery & OEM", d:"Component sourcing and fastener supply for machinery manufacturers and OEMs."},
  {name:"Infrastructure", d:"Fasteners and hardware for infrastructure and civil engineering projects."},
  {name:"Maintenance & Workshops", d:"Regular supply of maintenance products, tools, fasteners and industrial consumables."},
  {name:"HVAC", d:"Hardware, fasteners and consumables for HVAC installation and servicing."},
  {name:"Workshops", d:"General fastener, hardware and tool supply for day-to-day workshop needs."},
];

const whyCards = [
  {t:"Wide Product Range",d:"Source multiple industrial products from one reliable supplier.",icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7h18M3 12h18M3 17h18"/></svg>`},
  {t:"Competitive Pricing",d:"Competitive prices for regular and bulk requirements.",icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="9"/><path d="M12 7v10M9 10h6M9 14h6"/></svg>`},
  {t:"Bulk Supply",d:"Support for quantity-based requirements and regular supplies.",icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7M12 11v10"/></svg>`},
  {t:"Quality-Focused Sourcing",d:"Products sourced according to customer specifications and application requirements.",icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg>`},
  {t:"Fast Response",d:"Quick response to enquiries, quotations and product requirements.",icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>`},
  {t:"Customized Sourcing",d:"Unable to find a particular item? Share your part number, drawing, BOQ or sample requirement with us.",icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 19l5-1 10-10-4-4L5 14l-1 5z"/></svg>`},
];

const qaItems = [
  "Product specification verification",
  "Dimensional checking",
  "Material / specification verification where applicable",
  "Surface finish checking",
  "Quantity verification",
  "Packing inspection",
  "Supplier quality evaluation",
  "Dispatch inspection",
];

const qaInputs = ["Part Number","Product Drawing","Sample","Specification Sheet","BOQ","Excel Parts List","PDF Requirement"];

/* Brands with indicative sourced categories, per SLV Enterprises' developer notes:
   only brands SLV is authorized to represent or legitimately supplies should be shown. */
const brands = [
  {name:"TVS", cats:["Fasteners"]},
  {name:"KARAM", cats:["Safety Equipment"]},
  {name:"Unbrako", cats:["Fasteners","Bolts & Screws"]},
  {name:"fischer", cats:["Fasteners","Anchors"]},
  {name:"Freemans", cats:["Measuring Tools"]},
  {name:"HiKOKI", cats:["Power Tools"]},
  {name:"Aristo", cats:["Measuring Tools"]},
  {name:"Bosch", cats:["Power Tools"]},
  {name:"Jolly", cats:["Industrial Hardware"]},
  {name:"Janatics", cats:["Automation Components"]},
  {name:"NTN", cats:["Industrial Hardware","Bearings"]},
  {name:"Addison", cats:["Cutting Tools"]},
  {name:"Finolex", cats:["Industrial Cables"]},
  {name:"3M", cats:["Abrasives","Consumables"]},
  {name:"SKF", cats:["Industrial Hardware","Bearings"]},
  {name:"Anchor", cats:["Electrical Accessories"]},
  {name:"LAPP", cats:["Industrial Cables","Connectors"]},
  {name:"PATTA", cats:["Fasteners"]},
  {name:"RAAJ", cats:["Fasteners"]},
  {name:"Taparia", cats:["Hand Tools"]},
  {name:"Polycab", cats:["Industrial Cables"]},
  {name:"Stanley", cats:["Hand Tools","Power Tools"]},
  {name:"Totem", cats:["Industrial Hardware"]},
  {name:"JK", cats:["Fasteners"]},
  {name:"HILTI", cats:["Fasteners","Power Tools"]},
  {name:"nbc", cats:["Industrial Hardware","Bearings"]},
  {name:"Miranda", cats:["Electrical Accessories"]},
  {name:"Eastman", cats:["Hand Tools"]},
];

const catalogueDocs = [
  {t:"Company Profile", d:"Overview of SLV Enterprises and our product range."},
  {t:"Industrial Fasteners Catalogue", d:"Full fastener range with categories and subtypes."},
  {t:"Product Catalogue", d:"Complete product listing across all categories."},
  {t:"Industrial Hardware Catalogue", d:"Hardware components and mounting accessories."},
  {t:"Tools Catalogue", d:"Hand, power, cutting and measuring tools."},
  {t:"Product Specification Sheets", d:"Detailed specifications for individual products."},
];

const galleryCats = [
  {t:"Products", s:"Fasteners, screws, nuts, washers, hardware, tools"},
  {t:"Warehouse", s:"Stock, storage, packing"},
  {t:"Operations", s:"Inspection, packing, dispatch"},
  {t:"Company", s:"Office, team, facility"},
];

const knowledgeArticles = [
  {t:"Complete Guide to Industrial Fasteners", a:"Industrial fasteners cover a broad family of bolts, screws, nuts, washers and related hardware, each suited to particular loads, materials and assembly methods. Choosing correctly starts with understanding the joint: the materials being joined, the load direction, and whether the joint needs to be removable. Getting this right up front avoids costly rework and premature failure."},
  {t:"How to Select the Correct Bolt for Your Application", a:"Bolt selection depends on the load the joint carries, the operating environment, and the material being fastened. Key factors include diameter and length, thread type, grade, and finish. For vibration-prone applications, a locking mechanism such as a lock nut or spring washer is usually recommended alongside the bolt itself."},
  {t:"Understanding Metric Fastener Sizes", a:"Metric fasteners are specified by nominal diameter and thread pitch, written as, for example, M12 x 1.75. The diameter refers to the outer thread diameter in millimetres, while the pitch is the distance between threads. Matching both figures precisely between a bolt and its mating nut or tapped hole is essential for a secure fit."},
  {t:"Allen Bolt vs Hex Bolt – What's the Difference?", a:"An Allen bolt (socket head cap screw) is driven with a hex key inserted into its head, giving a compact, low-profile fastening point often used in machinery. A hex bolt has an external six-sided head driven with a spanner or socket, and is more common in structural and general assembly work where higher torque is applied by hand tools."},
  {t:"SS304 vs SS316 Stainless Steel Fasteners", a:"SS304 is a general-purpose stainless steel fastener grade suited to most indoor and moderate outdoor environments. SS316 includes molybdenum, giving it greater resistance to chlorides and corrosive environments, making it the preferred choice for marine, chemical or coastal applications. Contact SLV Enterprises to confirm current availability of each grade."},
  {t:"Understanding Fastener Grades", a:"Fastener grade indicates the material strength of a bolt or screw, commonly marked on the head as numbers such as 8.8 or 10.9 for metric fasteners. The first number relates to tensile strength and the second to the yield-to-tensile ratio. Higher-graded fasteners are generally used in structural or high-load applications."},
  {t:"Self-Tapping Screw vs Machine Screw", a:"A self-tapping screw cuts its own thread as it is driven into the material, making it suited to sheet metal, plastic or pre-drilled holes without a tapped thread. A machine screw requires a pre-tapped hole or a nut, and is used where a uniform, repeatable thread is needed, such as in machined components."},
  {t:"How to Select the Right Washer", a:"Flat washers distribute clamping load and protect the surface being fastened. Spring washers add resistance to loosening under vibration. The choice depends on the joint's exposure to vibration, the surface finish being protected, and whether electrical bonding is required, in which case a toothed or star washer may be more suitable."},
  {t:"Industrial Fastener Storage Guidelines", a:"Fasteners should be stored in a dry, moisture-controlled environment to prevent corrosion, particularly for uncoated or mild steel items. Keeping stock organised by size, grade and material reduces picking errors on the production floor and makes stock counts and reordering more accurate."},
  {t:"How to Prepare an Industrial Parts List for Quotation", a:"A clear parts list speeds up quotation turnaround. Include the product name or part number, quantity, size or specification, material or grade, and any drawing or sample reference. Sharing this as an Excel sheet, PDF or BOQ through the Request a Quote form lets our team review and respond faster."},
];

const faqs = [
  {q:"What industrial products does SLV Enterprises supply?",a:"We supply industrial fasteners, industrial hardware, tools, industrial equipment (including safety equipment), industrial consumables and electrical/automation accessories. See the Products section for the full range."},
  {q:"Do you supply customized sourcing for a specific part number or drawing?",a:"Yes. Share your part number, drawing, BOQ or sample requirement through the Request a Quote form and our team will confirm availability."},
  {q:"Can I request a quotation for bulk requirements?",a:"Yes. Use the Bulk Requirement upload option or the Request a Quote form with your quantity and specification, and our team will respond with availability and pricing."},
  {q:"How can I send a parts list, BOQ or drawing?",a:"You can attach an Excel sheet, CSV, PDF, drawing or BOQ directly in the Request a Quote form, or email it to slventerprises0219@gmail.com."},
  {q:"Do you supply electrical and automation components?",a:"Yes, our Electrical Accessories range includes panel boards, switches, contactors, relays, terminal blocks, sensors and other automation-related components. Contact us to confirm availability for your requirement."},
  {q:"Do you supply components for CNC, robotics or conveyor systems?",a:"Yes, our Industrial Equipment range covers CNC, robotics, automation and conveyor-related components and supplies. Contact SLV Enterprises for specifications and availability."},
  {q:"What are SLV Enterprises' business hours?",a:"We are available Monday to Saturday, 9:30 AM to 7:00 PM. We are closed on Sundays. You can also reach us anytime by email or WhatsApp and we will respond during business hours."},
];

/* ===================== ICON SET ===================== */
const iconGeneric = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="9"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M6.3 6.3l2 2M15.7 15.7l2 2M17.7 6.3l-2 2M8.3 15.7l-2 2"/></svg>`;
const catIcons = {
  "Fasteners": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14.7 6.3a4 4 0 015.7 5.6l-6.5 6.5a4 4 0 01-5.6-5.7z"/><path d="M9.2 8.2l1.6 1.6M12.3 5.1l1.6 1.6"/></svg>`,
  "Industrial Hardware": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/></svg>`,
  "Tools": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14.7 6.3a4 4 0 015.7 5.6l-6.5 6.5a4 4 0 01-5.6-5.7l6.4-6.4z"/></svg>`,
  "Industrial Equipment": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="4" y="4" width="16" height="16" rx="1"/><path d="M9 4v16M4 9h16"/></svg>`,
  "Industrial Consumables": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7M12 11v10"/></svg>`,
  "Electrical Accessories": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M13 2L4 14h6l-1 8 9-12h-6z"/></svg>`,
};
const qaInputIcon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6"/></svg>`;

/* ===================== RENDER: TOP CATEGORY GRID ===================== */
const topCatGrid = document.getElementById('topCatGrid');
topCategories.forEach((c,i)=>{
  const el = document.createElement('div');
  el.className = 'card cat-card';
  el.innerHTML = `<div class="cat-num">CATEGORY 0${i+1}</div><div class="cat-icon">${c.icon}</div><h3>${c.name}</h3><p>${c.desc}</p>`;
  el.addEventListener('click', ()=>{
    activeCat = c.name;
    document.querySelectorAll('.cat-pill').forEach(p=>p.classList.toggle('active', p.dataset.cat===c.name));
    renderProducts();
    document.getElementById('products').scrollIntoView({behavior:'smooth'});
  });
  topCatGrid.appendChild(el);
});

/* ===================== RENDER: CATEGORY PILLS ===================== */
const catPillsEl = document.getElementById('catPills');
let activeCat = "All";
categories.forEach(c=>{
  const b = document.createElement('button');
  b.className = 'cat-pill' + (c===activeCat ? ' active':'');
  b.textContent = c;
  b.dataset.cat = c;
  b.addEventListener('click', ()=>{ activeCat = c; renderProducts(); document.querySelectorAll('.cat-pill').forEach(p=>p.classList.toggle('active', p.dataset.cat===c)); });
  catPillsEl.appendChild(b);
});

/* ===================== RENDER: PRODUCT GRID ===================== */
const productGrid = document.getElementById('productGrid');
const resultCount = document.getElementById('resultCount');
const searchInput = document.getElementById('productSearch');

function renderProducts(){
  const term = searchInput.value.trim().toLowerCase();
  const filtered = products.filter(p=>{
    const matchCat = activeCat==="All" || p.cat===activeCat;
    const matchTerm = !term || p.name.toLowerCase().includes(term) || p.desc.toLowerCase().includes(term) || p.sub.toLowerCase().includes(term);
    return matchCat && matchTerm;
  });
  resultCount.textContent = filtered.length + (filtered.length===1 ? ' product':' products');
  productGrid.innerHTML = '';
  if(filtered.length===0){
    productGrid.innerHTML = '<div class="no-results">No products match your search. Try a different term, or contact us directly for your requirement.</div>';
    return;
  }
  filtered.forEach((p,i)=>{
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <div class="product-thumb" data-tag="${p.cat}">${catIcons[p.cat]||iconGeneric}</div>
      <div class="product-body">
        <div class="sub-tag">${p.sub}</div>
        <h4>${p.name}</h4>
        <p>${p.desc}</p>
        <button class="btn btn-ghost btn-sm view-btn" type="button">View Details</button>
      </div>`;
    card.querySelector('.view-btn').addEventListener('click', (e)=>{ e.stopPropagation(); openModal(p); });
    card.addEventListener('click', ()=>openModal(p));
    productGrid.appendChild(card);
    requestAnimationFrame(()=>setTimeout(()=>card.classList.add('show'), i*14));
  });
}
searchInput.addEventListener('input', renderProducts);
renderProducts();

/* ===================== MODAL ===================== */
const modalScrim = document.getElementById('modalScrim');
function openModal(p){
  document.getElementById('modalCat').textContent = p.cat + ' — ' + p.sub;
  document.getElementById('modalName').textContent = p.name;
  document.getElementById('modalDesc').textContent = p.desc;
  document.getElementById('modalApp').textContent = p.app;
  document.getElementById('modalHero').innerHTML = catIcons[p.cat]||iconGeneric;
  document.getElementById('modalRfqBtn').onclick = ()=>{ document.getElementById('f-product').value = p.name; };
  document.getElementById('modalWaBtn').href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Hello SLV Enterprises, I would like to enquire about: ' + p.name)}`;
  modalScrim.classList.add('open');
}
document.getElementById('modalClose').addEventListener('click', ()=>modalScrim.classList.remove('open'));
modalScrim.addEventListener('click', (e)=>{ if(e.target===modalScrim) modalScrim.classList.remove('open'); });

/* ===================== WHY GRID ===================== */
const whyGrid = document.getElementById('whyGrid');
whyCards.forEach(w=>{
  const el = document.createElement('div');
  el.className = 'why-card';
  el.style.border = '1px solid rgba(170,179,189,.3)';
  el.innerHTML = `${w.icon}<h4>${w.t}</h4><p style="color:var(--steel-300);">${w.d}</p>`;
  whyGrid.appendChild(el);
});

/* ===================== INDUSTRIES ===================== */
const industryIcon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="10" width="7" height="10"/><rect x="14" y="4" width="7" height="16"/><path d="M3 20h18"/></svg>`;
const industryGrid = document.getElementById('industryGrid');
industries.forEach(ind=>{
  const el = document.createElement('div');
  el.className = 'industry-card';
  el.innerHTML = `${industryIcon}<h4>${ind.name}</h4><p>${ind.d}</p>`;
  industryGrid.appendChild(el);
});

/* ===================== QUALITY LIST ===================== */
const qaList = document.getElementById('qaList');
qaItems.forEach(q=>{
  const el = document.createElement('div');
  el.className = 'qa-item';
  el.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg><span>${q}</span>`;
  qaList.appendChild(el);
});
const qaInputGrid = document.getElementById('qaInputGrid');
qaInputs.forEach(q=>{
  const el = document.createElement('div');
  el.className = 'qa-input-chip';
  el.innerHTML = `${qaInputIcon}<span>${q}</span>`;
  qaInputGrid.appendChild(el);
});

/* ===================== BRANDS ===================== */
const brandGrid = document.getElementById('brandGrid');
brands.forEach(b=>{
  const el = document.createElement('div');
  el.className = 'brand-card';
  const initials = b.name.replace(/[^A-Za-z0-9]/g,'').slice(0,3).toUpperCase();
  el.innerHTML = `
    <div class="brand-mark">${initials}</div>
    <h4>${b.name}</h4>
    <div class="brand-cats">${b.cats.join(' &middot; ')}</div>
    <button class="btn btn-ghost btn-sm" type="button">View Products</button>`;
  el.querySelector('button').addEventListener('click', ()=>{
    const matchCat = categories.find(c => b.cats.some(bc => bc.toLowerCase().includes(c.toLowerCase()) || c.toLowerCase().includes(bc.toLowerCase())));
    activeCat = matchCat || "All";
    document.querySelectorAll('.cat-pill').forEach(p=>p.classList.toggle('active', p.dataset.cat===activeCat));
    renderProducts();
    document.getElementById('products').scrollIntoView({behavior:'smooth'});
  });
  brandGrid.appendChild(el);
});

/* ===================== CATALOGUE ===================== */
const catalogueGrid = document.getElementById('catalogueGrid');
const docIcon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6"/></svg>`;
catalogueDocs.forEach(d=>{
  const el = document.createElement('div');
  el.className = 'card cat-doc';
  el.innerHTML = `${docIcon}<h4>${d.t}</h4><p>${d.d}</p><a href="#rfq" class="btn btn-ghost btn-sm">Request This Document</a>`;
  catalogueGrid.appendChild(el);
});

/* ===================== GALLERY ===================== */
const galleryGrid = document.getElementById('galleryGrid');
const galleryIcon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="3" width="18" height="18" rx="1"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></svg>`;
galleryCats.forEach(g=>{
  const el = document.createElement('div');
  el.className = 'gallery-tile';
  el.innerHTML = `${galleryIcon}<b>${g.t}</b><span>${g.s}</span><span style="color:#f5871f;">Photography coming soon</span>`;
  galleryGrid.appendChild(el);
});

/* ===================== KNOWLEDGE CENTRE ===================== */
const kcList = document.getElementById('kcList');
knowledgeArticles.forEach((k,i)=>{
  const item = document.createElement('div');
  item.className = 'kc-item';
  item.innerHTML = `
    <button class="kc-q" type="button"><span class="num">0${i+1}</span>${k.t}<span class="plus">+</span></button>
    <div class="kc-a"><p>${k.a}</p><div class="kc-cta"><a href="#rfq" class="btn btn-ghost btn-sm">Request a Quote</a></div></div>`;
  const btn = item.querySelector('.kc-q');
  const ans = item.querySelector('.kc-a');
  btn.addEventListener('click', ()=>{
    const isOpen = item.classList.contains('open');
    kcList.querySelectorAll('.kc-item').forEach(x=>{ x.classList.remove('open'); x.querySelector('.kc-a').style.maxHeight=null; });
    if(!isOpen){ item.classList.add('open'); ans.style.maxHeight = ans.scrollHeight+'px'; }
  });
  kcList.appendChild(item);
});

/* ===================== FAQ ===================== */
const faqList = document.getElementById('faqList');
faqs.forEach(f=>{
  const item = document.createElement('div');
  item.className = 'faq-item';
  item.innerHTML = `<button class="faq-q" type="button">${f.q}<span class="plus">+</span></button><div class="faq-a"><p>${f.a}</p></div>`;
  const btn = item.querySelector('.faq-q');
  const ans = item.querySelector('.faq-a');
  btn.addEventListener('click', ()=>{
    const isOpen = item.classList.contains('open');
    faqList.querySelectorAll('.faq-item').forEach(i=>{ i.classList.remove('open'); i.querySelector('.faq-a').style.maxHeight=null; });
    if(!isOpen){ item.classList.add('open'); ans.style.maxHeight = ans.scrollHeight+'px'; }
  });
  faqList.appendChild(item);
});

/* ===================== MOBILE MENU ===================== */
const hamburgerBtn = document.getElementById('hamburgerBtn');
const closeMenuBtn = document.getElementById('closeMenuBtn');
const mobileMenu = document.getElementById('mobileMenu');
const scrim = document.getElementById('scrim');
function openMenu(){ mobileMenu.classList.add('open'); scrim.classList.add('open'); }
function closeMenu(){ mobileMenu.classList.remove('open'); scrim.classList.remove('open'); }
hamburgerBtn.addEventListener('click', openMenu);
closeMenuBtn.addEventListener('click', closeMenu);
scrim.addEventListener('click', closeMenu);
mobileMenu.querySelectorAll('a').forEach(a=>a.addEventListener('click', closeMenu));

/* ===================== FILE UPLOAD ===================== */
const fileDrop = document.getElementById('fileDrop');
const fileInput = document.getElementById('f-file');
const fileDropText = document.getElementById('fileDropText');
fileDrop.addEventListener('click', ()=>fileInput.click());
fileInput.addEventListener('change', ()=>{
  if(fileInput.files.length){ fileDropText.textContent = fileInput.files[0].name; fileDrop.classList.add('has-file'); }
});

/* ===================== RFQ FORM VALIDATION ===================== */
const rfqForm = document.getElementById('rfqForm');
const formStatus = document.getElementById('formStatus');
const successBox = document.getElementById('successBox');

function validateField(field, value){
  switch(field){
    case 'name': return value.trim().length > 1;
    case 'company': return value.trim().length > 1;
    case 'mobile': return /^[0-9+\-\s()]{7,15}$/.test(value.trim());
    case 'email': return value.trim()==='' || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
    case 'product': return value.trim().length > 1;
    case 'qty': return value.trim().length > 0;
    default: return true;
  }
}

rfqForm.addEventListener('submit', function(e){
  e.preventDefault();
  let valid = true;
  ['name','company','mobile','email','product','qty'].forEach(field=>{
    const wrap = rfqForm.querySelector(`[data-field="${field}"]`);
    const input = wrap.querySelector('input');
    const ok = validateField(field, input.value);
    wrap.classList.toggle('error', !ok);
    if(!ok) valid = false;
  });
  if(!valid){ formStatus.textContent = 'Please check the highlighted fields.'; return; }
  formStatus.textContent = '';
  successBox.classList.add('show');
  rfqForm.querySelector('button[type="submit"]').style.display = 'none';
  successBox.scrollIntoView({behavior:'smooth', block:'center'});
});

/* ===================== SCROLL REVEAL ===================== */
const revealEls = document.querySelectorAll('.reveal');
const io = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{ if(entry.isIntersecting){ entry.target.classList.add('show'); io.unobserve(entry.target); } });
}, {threshold:0.1});
revealEls.forEach(el=>io.observe(el));
