Place website images, logos, PDFs and other static assets in this folder.
The current supplied code uses inline SVG icons and does not require external images to render.
